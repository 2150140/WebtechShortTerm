# advocacy-and-awareness-site

This site is for bringing awareness for the harmful effects of drugs. It contains information about drug abuse, remedies, and location for help.

website url can be found here:
[Advocacy Awareness project](https://christopheredrian.github.io/advocacy-and-awareness-site/index.html)
